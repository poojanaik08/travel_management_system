/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Airplainn;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;
import login_sys.home_page;

/**
 *
 * @author TANVI
 */
public class Airplainn extends javax.swing.JFrame {

    /**
     * Creates new form Airplainn
     */
    public Airplainn() {
        initComponents();
    }
    public boolean Validation()
    {
        String Name= txtFullName.getText();
        String Age= txtAge.getText();
        String PhoneNo=txtPhoneNo.getText();
        String email= txtemailid.getText();
        String carryonbags=jTextField1.getText();
        Date doj= jDateChooser1.getDate();
        if(Name.equals(""))
        {
            JOptionPane.showMessageDialog(this, "Please enter your name");
            return false;
        }
        if(Age.equals(""))
        {
            JOptionPane.showMessageDialog(this, "Please enter your age");
            return false;
        }
        if(PhoneNo.equals(""))
        {
            JOptionPane.showMessageDialog(this, "Please enter your phone no");
            return false;
        }
        if(email.equals(""))
        {
            JOptionPane.showMessageDialog(this, "Please enter your email id");
            return false;
        }
        if(doj==null)
        {
            JOptionPane.showMessageDialog(this, "Please enter your date of journey");
            return false;
        }
        if(carryonbags.equals(""))
        {
            JOptionPane.showMessageDialog(this, "Please enter No.of Carry on Bags");
            return false;
        }
        if(jRadioButton1.isSelected()==false && jRadioButton2.isSelected()==false)
        {  JOptionPane.showMessageDialog(this, "Please enter Class");
            return false;
        }   
        if(jComboBox1.getSelectedItem().equals("None"))
        {
            JOptionPane.showMessageDialog(this, "Please select Source");
            return false;
        }
        
        if(jComboBox2.getSelectedItem().equals("None"))
        {
            JOptionPane.showMessageDialog(this, "Please select Destination");
            return false;
        }
        
       return true;
       
    }
    public void Bill()
    {
        String Name= txtFullName.getText();
        String Age= txtAge.getText();
        String PhoneNo=txtPhoneNo.getText();
        String email= txtemailid.getText();
        String carryonbags=jTextField1.getText();
        String Destination = (String) jComboBox2.getSelectedItem();
        SimpleDateFormat dateFormt = new SimpleDateFormat("dd-MMM-y");
        String Source = (String) jComboBox1.getSelectedItem();
        String date = dateFormt.format(jDateChooser1.getDate());
        String Business =lblbusiness.getText();
        String Economy =lbleconomy.getText();
        String FlightNumber =jLabel11.getText();
        String TimeofFlight =jLabel15.getText();
        String Passenger = (String) jComboBoxPassenger.getSelectedItem();
        
       
        if(jDateChooser1.isShowing()==true){
        txtbill.setText(null);
        }
        
        txtbill.setText(txtbill.getText()+"*******************************************\n");
        txtbill.setText(txtbill.getText()+"*****************RECEIPT*****************\n");
        txtbill.setText(txtbill.getText()+"*******************************************\n\n\n\n\n");
        txtbill.setText(txtbill.getText()+"Passenger's Name:         " + Name +"\n");
        txtbill.setText(txtbill.getText()+"Passenger's Age:            " + Age +"\n");
        txtbill.setText(txtbill.getText()+"Passenger's Phone No.:  " + PhoneNo +"\n");
        txtbill.setText(txtbill.getText()+"Passenger's Email:          "+ email +"\n\n");
        
       
        txtbill.setText(txtbill.getText()+"Source:                           "+ Source+ "\n");
        txtbill.setText(txtbill.getText()+"Destination:                     "+ Destination+ "\n");
        txtbill.setText(txtbill.getText()+"No. of Passengers:           "+Passenger+"\n");
        txtbill.setText(txtbill.getText()+"Date of Journey:              "+ date+"\n\n");
        
        txtbill.setText(txtbill.getText()+"Flight Number:                "+FlightNumber+"\n");
        txtbill.setText(txtbill.getText()+"Time of Flight:                "+TimeofFlight+"\n");
        txtbill.setText(txtbill.getText()+"Carry on Bags:                "+ carryonbags+ "\n");
           
        
        if(jRadioButton1.isSelected())
        {
        txtbill.setText(txtbill.getText()+"Class:                            Business Class\n");
        txtbill.setText(txtbill.getText()+"Total Amount:                "+ Business+ "\n");
            
        }
        
        if(jRadioButton2.isSelected())
        {
        txtbill.setText(txtbill.getText()+"Class:                            Economy Class\n");
        txtbill.setText(txtbill.getText()+"Total Amount:                "+ Economy+ "\n");
            
        }
        txtbill.setText(txtbill.getText()+"\n\n\n\n\n\n******************************************\n");
        txtbill.setText(txtbill.getText()+"Note: Amount is inclusive of all taxes\n");
        txtbill.setText(txtbill.getText()+"Please take a screenshot for further reference");
    }
    
    public void databaseConnection(){
        String name= txtFullName.getText();
        
        String phoneno=txtPhoneNo.getText();
        String email= txtemailid.getText();
        
        String destination = (String) jComboBox2.getSelectedItem();
        SimpleDateFormat dateFormt = new SimpleDateFormat("dd-MMM-y");
        String source = (String) jComboBox1.getSelectedItem();
        String date = dateFormt.format(jDateChooser1.getDate());
        String passenger = (String) jComboBoxPassenger.getSelectedItem();
        
        String flightnumber =jLabel11.getText();
        String timeofflight =jLabel15.getText();
        
        try{
        Class.forName("org.postgresql.Driver");
        Connection con= DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres","postgres","pluto21");
        Statement st= con.createStatement();
        String sql= "insert into information_schema.trainbooking values('"+name+"','"+phoneno+"','"+email+"','"+source+"','"+destination+"','"+date+"','"+timeofflight+"','"+flightnumber+"','"+passenger+"')";
        st.execute(sql);
       
        }
        catch(Exception e){
             JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txtFullName = new javax.swing.JTextField();
        txtAge = new javax.swing.JTextField();
        txtPhoneNo = new javax.swing.JTextField();
        txtemailid = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        jComboBox2 = new javax.swing.JComboBox<>();
        jLabel11 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jDateChooser1 = new com.toedter.calendar.JDateChooser();
        jLabel17 = new javax.swing.JLabel();
        jComboBoxPassenger = new javax.swing.JComboBox<>();
        jPanel4 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        jRadioButton1 = new javax.swing.JRadioButton();
        jRadioButton2 = new javax.swing.JRadioButton();
        lbleconomy = new javax.swing.JLabel();
        lblbusiness = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtbill = new javax.swing.JTextArea();
        jButton3 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBounds(new java.awt.Rectangle(0, 0, 0, 0));
        setPreferredSize(new java.awt.Dimension(1200, 780));
        addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                formPropertyChange(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 4));
        jPanel1.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        jPanel1.setName(""); // NOI18N

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 48)); // NOI18N
        jLabel1.setText("FLIGHT BOOKING");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(399, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(321, 321, 321))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 82, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 1160, -1));

        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 4));

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel2.setText("PERSONAL DETAILS");

        jLabel3.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel3.setText("Full Name");

        jLabel4.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel4.setText("Age");

        jLabel5.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel5.setText("Phone No");

        jLabel6.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel6.setText("email ");

        txtFullName.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N

        txtAge.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N

        txtPhoneNo.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N

        txtemailid.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(jPanel2Layout.createSequentialGroup()
                                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(48, 48, 48)
                                    .addComponent(txtemailid))
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(txtPhoneNo, javax.swing.GroupLayout.PREFERRED_SIZE, 221, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(145, 145, 145)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(txtFullName, javax.swing.GroupLayout.PREFERRED_SIZE, 221, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtAge, javax.swing.GroupLayout.PREFERRED_SIZE, 221, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(34, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 251, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(68, 68, 68))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtFullName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(33, 33, 33)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txtAge, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(44, 44, 44)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(txtPhoneNo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(41, 41, 41)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(txtemailid, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(20, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 108, -1, -1));

        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 4));

        jLabel7.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel7.setText("BOOKING DETAILS");

        jLabel8.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel8.setText("Source");

        jLabel9.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel9.setText("Destination");

        jLabel10.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel10.setText("Date of Journey");

        jLabel12.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel12.setText("Flight No");

        jComboBox1.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "None", "Mumbai" }));
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });

        jComboBox2.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "None", "Kashmir", "Chennai", "Jaipur", "Gangtok" }));
        jComboBox2.setEnabled(false);
        jComboBox2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox2ActionPerformed(evt);
            }
        });

        jLabel11.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel11.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel14.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel14.setText("Flight time");

        jLabel15.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel15.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel16.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel16.setText("Carry on bags (in number)");

        jTextField1.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jTextField1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jDateChooser1.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N

        jLabel17.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel17.setText("Passenger(s)");

        jComboBoxPassenger.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jComboBoxPassenger.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "One", "Two", "Three", "Four" }));
        jComboBoxPassenger.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxPassengerActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(95, 95, 95)
                        .addComponent(jLabel7))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel14)))
                .addGap(0, 67, Short.MAX_VALUE))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel16)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel10)
                                    .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel9)))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel17)
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel11, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jComboBox2, javax.swing.GroupLayout.Alignment.TRAILING, 0, 253, Short.MAX_VALUE)
                            .addComponent(jComboBox1, javax.swing.GroupLayout.Alignment.TRAILING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jDateChooser1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jComboBoxPassenger, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel7)
                .addGap(39, 39, 39)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(38, 38, 38)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(51, 51, 51)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, 27, Short.MAX_VALUE)
                    .addComponent(jDateChooser1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(46, 46, 46)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel12))
                .addGap(35, 35, 35)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel14, javax.swing.GroupLayout.DEFAULT_SIZE, 29, Short.MAX_VALUE)
                    .addComponent(jLabel15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 46, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel17)
                    .addComponent(jComboBoxPassenger, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(45, 45, 45)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel16))
                .addContainerGap())
        );

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 110, 400, 568));

        jPanel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 4));

        jLabel13.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel13.setText("CLASS");

        jRadioButton1.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jRadioButton1.setText("Business");
        jRadioButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton1ActionPerformed(evt);
            }
        });

        jRadioButton2.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jRadioButton2.setText("Economy");
        jRadioButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton2ActionPerformed(evt);
            }
        });

        lbleconomy.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        lbleconomy.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        lblbusiness.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        lblbusiness.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(44, 44, 44)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jRadioButton2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jRadioButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(lbleconomy, javax.swing.GroupLayout.DEFAULT_SIZE, 197, Short.MAX_VALUE)
                            .addComponent(lblbusiness, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(157, 157, 157)
                        .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(46, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addComponent(jLabel13)
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jRadioButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblbusiness, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE))
                .addGap(33, 33, 33)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbleconomy, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jRadioButton2))
                .addContainerGap(51, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 466, 408, 210));

        jButton1.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jButton1.setText("Back");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 690, -1, -1));

        jButton2.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jButton2.setText("Next");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(1100, 690, -1, -1));

        txtbill.setEditable(false);
        txtbill.setColumns(20);
        txtbill.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        txtbill.setRows(5);
        txtbill.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        jScrollPane1.setViewportView(txtbill);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(845, 108, 330, 568));

        jButton3.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jButton3.setText("Receipt");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 690, 100, 30));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        NewFlightCancellation nc = new NewFlightCancellation();
        nc.show();
        dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void formPropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_formPropertyChange
        // TODO add your handling code here:
    }//GEN-LAST:event_formPropertyChange
   
    
    private void jComboBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox2ActionPerformed
        // TODO add your handling code here:
        if(jComboBox2.getSelectedItem().equals("Chennai") && jRadioButton1.isSelected()&&jComboBox1.getSelectedItem().equals("Mumbai"))
        {
            lblbusiness.setText("Rs 1968/-");
            jLabel11.setText("AI0127");
            jLabel15.setText("13:00 IST");
            txtbill.setText(null);
            
        }
         if(jComboBox2.getSelectedItem().equals("Gangtok") && jRadioButton1.isSelected()&&jComboBox1.getSelectedItem().equals("Mumbai"))
        {
            lblbusiness.setText("Rs 7546/-");
            jLabel11.setText("9W3110");
            jLabel15.setText("23:00 IST");
            txtbill.setText(null);
        }
         if(jComboBox2.getSelectedItem().equals("Kashmir") && jRadioButton1.isSelected()&&jComboBox1.getSelectedItem().equals("Mumbai"))
        {
            lblbusiness.setText("Rs 1200/-");
            jLabel11.setText("6E1894");
            jLabel15.setText("11:00 IST");
            txtbill.setText(null);
            
        }
          if(jComboBox2.getSelectedItem().equals("Jaipur") && jRadioButton1.isSelected()&&jComboBox1.getSelectedItem().equals("Mumbai"))
        {
            lblbusiness.setText("Rs 4405/-");
            jLabel11.setText("IT3322");
            jLabel15.setText("07:00 IST");
            txtbill.setText(null);
        }
         if(jComboBox2.getSelectedItem().equals("Chennai") && jRadioButton2.isSelected()&&jComboBox1.getSelectedItem().equals("Mumbai"))
        {
            lbleconomy.setText("Rs 3968/-");
            jLabel11.setText("AI0127");
            jLabel15.setText("13:00 IST");
            txtbill.setText(null);
        }
        if(jComboBox2.getSelectedItem().equals("Kashmir") && jRadioButton2.isSelected()&&jComboBox1.getSelectedItem().equals("Mumbai"))
        {
            lbleconomy.setText("Rs 10000/-");
            jLabel11.setText("6E1894");
            jLabel15.setText("11:00 IST");
            txtbill.setText(null);
        }
        if(jComboBox2.getSelectedItem().equals("Jaipur") && jRadioButton2.isSelected()&&jComboBox1.getSelectedItem().equals("Mumbai"))
        {
            lbleconomy.setText("Rs 2405/-");
            jLabel11.setText("IT3322");
            jLabel15.setText("07:00 IST");
            txtbill.setText(null);
        }
          if(jComboBox2.getSelectedItem().equals("Gangtok") && jRadioButton2.isSelected()&&jComboBox1.getSelectedItem().equals("Mumbai"))
        {
            lbleconomy.setText("Rs 4546/-");
            jLabel11.setText("9W3110");
            jLabel15.setText("23:00 IST");
            txtbill.setText(null);
        }
    }//GEN-LAST:event_jComboBox2ActionPerformed

    private void jRadioButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton1ActionPerformed
        // TODO add your handling code here:
        if(jRadioButton1.isSelected()==true)
        {
            lblbusiness.setText(null);
            lbleconomy.setText(null);
            jComboBox2.setEnabled(true);
            jRadioButton2.setSelected(false);
            jComboBox1.setSelectedItem("None");
            jComboBox2.setSelectedItem("None");
            jLabel11.setText(null);
            jLabel15.setText(null);
            txtbill.setText(null);
            jComboBoxPassenger.setSelectedItem("One");
        }
        if(jRadioButton1.isSelected()==false)
        {
            lblbusiness.setText(null);
            lbleconomy.setText(null);
            jComboBox2.setEnabled(false);
            jRadioButton2.setSelected(false);
            jComboBox1.setSelectedItem("None");
            jComboBox2.setSelectedItem("None");
            jLabel11.setText(null);
            jLabel15.setText(null);
            txtbill.setText(null);
            jComboBoxPassenger.setSelectedItem("One");

        }
    }//GEN-LAST:event_jRadioButton1ActionPerformed

    private void jRadioButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton2ActionPerformed
        // TODO add your handling code here:
        if(jRadioButton2.isSelected()==true)
        {
            lblbusiness.setText(null);
            lbleconomy.setText(null);
            jComboBox2.setEnabled(true);
            jRadioButton1.setSelected(false);
            jComboBox1.setSelectedItem("None");
            jComboBox2.setSelectedItem("None");
            jLabel11.setText(null);
            jLabel15.setText(null);
            txtbill.setText(null);
            jComboBoxPassenger.setSelectedItem("One");
        }
        if(jRadioButton2.isSelected()==false)
        {
            lblbusiness.setText(null);
            lbleconomy.setText(null);
            jComboBox2.setEnabled(false);
            jRadioButton1.setSelected(false);
            jComboBox1.setSelectedItem("None");
            jComboBox2.setSelectedItem("None");
            jLabel11.setText(null);
            jLabel15.setText(null);
            txtbill.setText(null);
            jComboBoxPassenger.setSelectedItem("One");

        }
    
    }//GEN-LAST:event_jRadioButton2ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        if(Validation()==true){
            databaseConnection();
            AirplanePayment ap = new AirplanePayment();
            ap.show();
            dispose();
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        Bill();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        // TODO add your handling code here:
        txtbill.setText(null);
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void jComboBoxPassengerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxPassengerActionPerformed
        // TODO add your handling code here:
        if(jComboBox2.getSelectedItem().equals("Chennai") && jRadioButton1.isSelected()&&jComboBox1.getSelectedItem().equals("Mumbai")&&jComboBoxPassenger.getSelectedItem().equals("Two"))
        {
            lblbusiness.setText("Rs 3936/-");
            jLabel11.setText("AI0127");
            jLabel15.setText("13:00 IST");
            txtbill.setText(null);
            
        }
        if(jComboBox2.getSelectedItem().equals("Chennai") && jRadioButton1.isSelected()&&jComboBox1.getSelectedItem().equals("Mumbai")&&jComboBoxPassenger.getSelectedItem().equals("Three"))
        {
            lblbusiness.setText("Rs 5904/-");
            jLabel11.setText("AI0127");
            jLabel15.setText("13:00 IST");
            txtbill.setText(null);
            
        }
        if(jComboBox2.getSelectedItem().equals("Chennai") && jRadioButton1.isSelected()&&jComboBox1.getSelectedItem().equals("Mumbai")&&jComboBoxPassenger.getSelectedItem().equals("Four"))
        {
            lblbusiness.setText("Rs 7872/-");
            jLabel11.setText("AI0127");
            jLabel15.setText("13:00 IST");
            txtbill.setText(null);
            
        }
         if(jComboBox2.getSelectedItem().equals("Gangtok") && jRadioButton1.isSelected()&&jComboBox1.getSelectedItem().equals("Mumbai")&&jComboBoxPassenger.getSelectedItem().equals("Two"))
        {
            lblbusiness.setText("Rs 14952/-");
            jLabel11.setText("9W3110");
            jLabel15.setText("23:00 IST");
            txtbill.setText(null);
        }
         if(jComboBox2.getSelectedItem().equals("Gangtok") && jRadioButton1.isSelected()&&jComboBox1.getSelectedItem().equals("Mumbai")&&jComboBoxPassenger.getSelectedItem().equals("Three"))
        {
            lblbusiness.setText("Rs 22428/-");
            jLabel11.setText("9W3110");
            jLabel15.setText("23:00 IST");
            txtbill.setText(null);
        }
         if(jComboBox2.getSelectedItem().equals("Gangtok") && jRadioButton1.isSelected()&&jComboBox1.getSelectedItem().equals("Mumbai")&&jComboBoxPassenger.getSelectedItem().equals("Four"))
        {
            lblbusiness.setText("Rs 29904/-");
            jLabel11.setText("9W3110");
            jLabel15.setText("23:00 IST");
            txtbill.setText(null);
        }
         if(jComboBox2.getSelectedItem().equals("Kashmir") && jRadioButton1.isSelected()&&jComboBox1.getSelectedItem().equals("Mumbai")&&jComboBoxPassenger.getSelectedItem().equals("Two"))
        {
            lblbusiness.setText("Rs 2400/-");
            jLabel11.setText("6E1894");
            jLabel15.setText("11:00 IST");
            txtbill.setText(null);
            
        }
          if(jComboBox2.getSelectedItem().equals("Kashmir") && jRadioButton1.isSelected()&&jComboBox1.getSelectedItem().equals("Mumbai")&&jComboBoxPassenger.getSelectedItem().equals("Three"))
        {
            lblbusiness.setText("Rs 3600/-");
            jLabel11.setText("6E1894");
            jLabel15.setText("11:00 IST");
            txtbill.setText(null);
            
        }
           if(jComboBox2.getSelectedItem().equals("Kashmir") && jRadioButton1.isSelected()&&jComboBox1.getSelectedItem().equals("Mumbai")&&jComboBoxPassenger.getSelectedItem().equals("Four"))
        {
            lblbusiness.setText("Rs 4800/-");
            jLabel11.setText("6E1894");
            jLabel15.setText("11:00 IST");
            txtbill.setText(null);
            
        }
          if(jComboBox2.getSelectedItem().equals("Jaipur") && jRadioButton1.isSelected()&&jComboBox1.getSelectedItem().equals("Mumbai")&&jComboBoxPassenger.getSelectedItem().equals("Two"))
        {
            lblbusiness.setText("Rs 8810/-");
            jLabel11.setText("IT3322");
            jLabel15.setText("07:00 IST");
            txtbill.setText(null);
        }
          if(jComboBox2.getSelectedItem().equals("Jaipur") && jRadioButton1.isSelected()&&jComboBox1.getSelectedItem().equals("Mumbai")&&jComboBoxPassenger.getSelectedItem().equals("Three"))
        {
            lblbusiness.setText("Rs 13215/-");
            jLabel11.setText("IT3322");
            jLabel15.setText("07:00 IST");
            txtbill.setText(null);
        }
          if(jComboBox2.getSelectedItem().equals("Jaipur") && jRadioButton1.isSelected()&&jComboBox1.getSelectedItem().equals("Mumbai")&&jComboBoxPassenger.getSelectedItem().equals("Four"))
        {
            lblbusiness.setText("Rs 17620/-");
            jLabel11.setText("IT3322");
            jLabel15.setText("07:00 IST");
            txtbill.setText(null);
        }
         if(jComboBox2.getSelectedItem().equals("Chennai") && jRadioButton2.isSelected()&&jComboBox1.getSelectedItem().equals("Mumbai")&&jComboBoxPassenger.getSelectedItem().equals("Two"))
        {
            lbleconomy.setText("Rs 7936/-");
            jLabel11.setText("AI0127");
            jLabel15.setText("13:00 IST");
            txtbill.setText(null);
        }
         if(jComboBox2.getSelectedItem().equals("Chennai") && jRadioButton2.isSelected()&&jComboBox1.getSelectedItem().equals("Mumbai")&&jComboBoxPassenger.getSelectedItem().equals("Three"))
        {
            lbleconomy.setText("Rs 11904/-");
            jLabel11.setText("AI0127");
            jLabel15.setText("13:00 IST");
            txtbill.setText(null);
        }
         if(jComboBox2.getSelectedItem().equals("Chennai") && jRadioButton2.isSelected()&&jComboBox1.getSelectedItem().equals("Mumbai")&&jComboBoxPassenger.getSelectedItem().equals("Four"))
        {
            lbleconomy.setText("Rs 15872/-");
            jLabel11.setText("AI0127");
            jLabel15.setText("13:00 IST");
            txtbill.setText(null);
        }
        if(jComboBox2.getSelectedItem().equals("Kashmir") && jRadioButton2.isSelected()&&jComboBox1.getSelectedItem().equals("Mumbai")&&jComboBoxPassenger.getSelectedItem().equals("Two"))
        {
            lbleconomy.setText("Rs 20000/-");
            jLabel11.setText("6E1894");
            jLabel15.setText("11:00 IST");
            txtbill.setText(null);
        }
        if(jComboBox2.getSelectedItem().equals("Kashmir") && jRadioButton2.isSelected()&&jComboBox1.getSelectedItem().equals("Mumbai")&&jComboBoxPassenger.getSelectedItem().equals("Three"))
        {
            lbleconomy.setText("Rs 30000/-");
            jLabel11.setText("6E1894");
            jLabel15.setText("11:00 IST");
            txtbill.setText(null);
        }
        if(jComboBox2.getSelectedItem().equals("Kashmir") && jRadioButton2.isSelected()&&jComboBox1.getSelectedItem().equals("Mumbai")&&jComboBoxPassenger.getSelectedItem().equals("Four"))
        {
            lbleconomy.setText("Rs 40000/-");
            jLabel11.setText("6E1894");
            jLabel15.setText("11:00 IST");
            txtbill.setText(null);
        }
        if(jComboBox2.getSelectedItem().equals("Jaipur") && jRadioButton2.isSelected()&&jComboBox1.getSelectedItem().equals("Mumbai")&&jComboBoxPassenger.getSelectedItem().equals("Two"))
        {
            lbleconomy.setText("Rs 4810/-");
            jLabel11.setText("IT3322");
            jLabel15.setText("07:00 IST");
            txtbill.setText(null);
        }
         if(jComboBox2.getSelectedItem().equals("Jaipur") && jRadioButton2.isSelected()&&jComboBox1.getSelectedItem().equals("Mumbai")&&jComboBoxPassenger.getSelectedItem().equals("Three"))
        {
            lbleconomy.setText("Rs 7215/-");
            jLabel11.setText("IT3322");
            jLabel15.setText("07:00 IST");
            txtbill.setText(null);
        }
          if(jComboBox2.getSelectedItem().equals("Jaipur") && jRadioButton2.isSelected()&&jComboBox1.getSelectedItem().equals("Mumbai")&&jComboBoxPassenger.getSelectedItem().equals("Four"))
        {
            lbleconomy.setText("Rs 9620/-");
            jLabel11.setText("IT3322");
            jLabel15.setText("07:00 IST");
            txtbill.setText(null);
        }
          if(jComboBox2.getSelectedItem().equals("Gangtok") && jRadioButton2.isSelected()&&jComboBox1.getSelectedItem().equals("Mumbai")&&jComboBoxPassenger.getSelectedItem().equals("Two"))
        {
            lbleconomy.setText("Rs 9092/-");
            jLabel11.setText("9W3110");
            jLabel15.setText("23:00 IST");
            txtbill.setText(null);
        }
          if(jComboBox2.getSelectedItem().equals("Gangtok") && jRadioButton2.isSelected()&&jComboBox1.getSelectedItem().equals("Mumbai")&&jComboBoxPassenger.getSelectedItem().equals("Three"))
        {
            lbleconomy.setText("Rs 13638/-");
            jLabel11.setText("9W3110");
            jLabel15.setText("23:00 IST");
            txtbill.setText(null);
        }
          if(jComboBox2.getSelectedItem().equals("Gangtok") && jRadioButton2.isSelected()&&jComboBox1.getSelectedItem().equals("Mumbai")&&jComboBoxPassenger.getSelectedItem().equals("Four"))
        {
            lbleconomy.setText("Rs 18184/-");
            jLabel11.setText("9W3110");
            jLabel15.setText("23:00 IST");
            txtbill.setText(null);
        }
    }//GEN-LAST:event_jComboBoxPassengerActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Airplainn.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Airplainn.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Airplainn.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Airplainn.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Airplainn().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JComboBox<String> jComboBoxPassenger;
    private com.toedter.calendar.JDateChooser jDateChooser1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JRadioButton jRadioButton2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JLabel lblbusiness;
    private javax.swing.JLabel lbleconomy;
    private javax.swing.JTextField txtAge;
    private javax.swing.JTextField txtFullName;
    private javax.swing.JTextField txtPhoneNo;
    private javax.swing.JTextArea txtbill;
    private javax.swing.JTextField txtemailid;
    // End of variables declaration//GEN-END:variables
}
