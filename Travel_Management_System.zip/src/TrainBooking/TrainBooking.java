/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TrainBooking;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;
import login_sys.home_page;



/**
 *
 * @author Khanvilkar
 */
public class TrainBooking extends javax.swing.JFrame {

    /**
     * Creates new form TrainBooking
     */
    public TrainBooking() {
        initComponents();
    }
    public boolean Validation()
    {
        String Name= txtName.getText();
        String Age= txtAge.getText();
        String PhoneNo=txtPhoneNo.getText();
        String email= txtEmail.getText();
       
        Date doj= jDateChooser1.getDate();
        if(Name.equals(""))
        {
            JOptionPane.showMessageDialog(this, "Please enter your name");
            return false;
        }
        if(Age.equals(""))
        {
            JOptionPane.showMessageDialog(this, "Please enter your age");
            return false;
        }
        if(PhoneNo.equals(""))
        {
            JOptionPane.showMessageDialog(this, "Please enter your phone no");
            return false;
        }
        if(email.equals(""))
        {
            JOptionPane.showMessageDialog(this, "Please enter your email id");
            return false;
        }
        if(doj==null)
        {
            JOptionPane.showMessageDialog(this, "Please enter your date of journey");
            return false;
        }
       
        if(jRadioButton1.isSelected()==false && jRadioButtonSecond.isSelected()==false)
        {  JOptionPane.showMessageDialog(this, "Please enter Class");
            return false;
        }   
        if(jComboBoxSource.getSelectedItem().equals("None"))
        {
            JOptionPane.showMessageDialog(this, "Please select Source");
            return false;
        }
        
        if(jComboBoxDestination.getSelectedItem().equals("None"))
        {
            JOptionPane.showMessageDialog(this, "Please select Destination");
            return false;
        }
       return true;
       
    }
    public void databaseConnection(){
        String name= txtName.getText();
        String Age= txtAge.getText();
        String phone=txtPhoneNo.getText();
        String email= txtEmail.getText();
       
        String destination = (String) jComboBoxDestination.getSelectedItem();
        SimpleDateFormat dateFormt = new SimpleDateFormat("dd-MMM-y");
        String source = (String) jComboBoxSource.getSelectedItem();
        String date = dateFormt.format(jDateChooser1.getDate());
        
        String passenger = (String) jComboBoxPassenger.getSelectedItem();
        String trainno=lblTrainNo.getText();
        String trainname=lblTrainName.getText();
        String time =jLabel12.getText();
        
        try{
        Class.forName("org.postgresql.Driver");
        Connection con= DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres","postgres","pluto21");
        Statement st= con.createStatement();
        String sql = "insert into information_schema.flightbooking values ('"+name+"','"+phone+"','"+email+"','"+destination+"','"+source+"','"+date+"','"+passenger+"','"+trainno+"','"+trainname+"','"+time+"')";
        st.execute(sql);
        
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(this, e.getMessage());
            
        }
    }
    public void Bill()
    {
        String Name= txtName.getText();
        String Age= txtAge.getText();
        String PhoneNo=txtPhoneNo.getText();
        String email= txtEmail.getText();
       
        String Destination = (String) jComboBoxDestination.getSelectedItem();
        SimpleDateFormat dateFormt = new SimpleDateFormat("dd-MMM-y");
        String Source = (String) jComboBoxSource.getSelectedItem();
        String date = dateFormt.format(jDateChooser1.getDate());
        String First = lblFirst.getText();
        String Second = lblSecond.getText();
        String Passenger = (String) jComboBoxPassenger.getSelectedItem();
        String TrainNo=lblTrainNo.getText();
        String TrainName=lblTrainName.getText();
        String Time =jLabel12.getText();
        
       
        
       
        if(jDateChooser1.isShowing()==true){
        txtbill.setText(null);
        }
        
        txtbill.setText(txtbill.getText()+"*****************************************\n");
        txtbill.setText(txtbill.getText()+"*****************RECEIPT****************\n");
        txtbill.setText(txtbill.getText()+"*****************************************\n\n\n");
        txtbill.setText(txtbill.getText()+"Passenger's Name:         " + Name +"\n");
        txtbill.setText(txtbill.getText()+"Passenger's Age:            " + Age +"\n");
        txtbill.setText(txtbill.getText()+"Passenger's Phone No.:  " + PhoneNo +"\n");
        txtbill.setText(txtbill.getText()+"Passenger's Email:          "+ email +"\n\n");
        
       
        txtbill.setText(txtbill.getText()+"Source:                          "+ Source+ "\n");
        txtbill.setText(txtbill.getText()+"Destination:                    "+ Destination+ "\n");
        txtbill.setText(txtbill.getText()+"No. of Passenger            "+ Passenger+"\n");
        txtbill.setText(txtbill.getText()+"Date of Journey:             "+ date+"\n");
         txtbill.setText(txtbill.getText()+"Departure time:               "+ Time+"\n\n");
        
       
         txtbill.setText(txtbill.getText()+"Train No.:                      "+TrainNo+"\n");
         txtbill.setText(txtbill.getText()+"Train Name:                   "+TrainName+"\n");
        if(jRadioButton1.isSelected())
        {
        txtbill.setText(txtbill.getText()+"Class:                             First Class\n");
        txtbill.setText(txtbill.getText()+"Total Amount:                "+ First+ "\n");
            
        }
        
        if(jRadioButtonSecond.isSelected())
        {
        txtbill.setText(txtbill.getText()+"Class:                             Second Class\n");
        txtbill.setText(txtbill.getText()+"Total Amount:                "+ Second+ "\n");
            
        }
        txtbill.setText(txtbill.getText()+"\n\n\n*****************************************\n");
        txtbill.setText(txtbill.getText()+"Note: Amount is inclusive of all taxes\n");
        txtbill.setText(txtbill.getText()+"Please take a screenshot for further reference");
    }
    
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txtName = new javax.swing.JTextField();
        txtAge = new javax.swing.JTextField();
        txtEmail = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        txtPhoneNo = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jComboBoxSource = new javax.swing.JComboBox<>();
        jComboBoxDestination = new javax.swing.JComboBox<>();
        jLabel11 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jComboBoxPassenger = new javax.swing.JComboBox<>();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        lblTrainNo = new javax.swing.JLabel();
        lblTrainName = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jDateChooser1 = new com.toedter.calendar.JDateChooser();
        jPanel4 = new javax.swing.JPanel();
        jRadioButton1 = new javax.swing.JRadioButton();
        jRadioButtonSecond = new javax.swing.JRadioButton();
        lblFirst = new javax.swing.JLabel();
        lblSecond = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtbill = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 3));

        jLabel14.setFont(new java.awt.Font("Times New Roman", 1, 48)); // NOI18N
        jLabel14.setText("TRAIN BOOKING");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(371, Short.MAX_VALUE)
                .addComponent(jLabel14)
                .addGap(342, 342, 342))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jLabel14)
                .addContainerGap(20, Short.MAX_VALUE))
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 3));

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel2.setText("PERSONAL DETAILS");

        jLabel3.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel3.setText("Name");

        jLabel4.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel4.setText("Age");

        jLabel5.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel5.setText("Email");

        txtName.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N

        txtAge.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N

        txtEmail.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N

        jLabel7.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel7.setText("Phone No.");

        txtPhoneNo.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        txtPhoneNo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPhoneNoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addComponent(jLabel3)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jLabel7)
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(txtAge)
                    .addComponent(txtEmail, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtPhoneNo)
                    .addComponent(txtName, javax.swing.GroupLayout.Alignment.LEADING))
                .addGap(58, 58, 58))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(100, 100, 100)
                .addComponent(jLabel2)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addGap(34, 34, 34)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtAge, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addGap(17, 17, 17)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtPhoneNo))
                .addGap(0, 40, Short.MAX_VALUE))
        );

        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 3));

        jLabel8.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel8.setText("   TRAIN DETAILS");

        jLabel9.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel9.setText("Source");

        jLabel10.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel10.setText("Destination");

        jComboBoxSource.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jComboBoxSource.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "None", "Mumbai", " " }));
        jComboBoxSource.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxSourceActionPerformed(evt);
            }
        });

        jComboBoxDestination.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jComboBoxDestination.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "None", "Pune", "Delhi", "Udaipur", "Surat" }));
        jComboBoxDestination.setEnabled(false);
        jComboBoxDestination.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxDestinationActionPerformed(evt);
            }
        });

        jLabel11.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel11.setText("Date of journey");

        jLabel13.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel13.setText("Passenger(s)");

        jComboBoxPassenger.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jComboBoxPassenger.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "One", "Two", "Three", "Four" }));
        jComboBoxPassenger.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxPassengerActionPerformed(evt);
            }
        });

        jLabel16.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel16.setText("Train No.");

        jLabel17.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel17.setText("Train Name");

        lblTrainNo.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        lblTrainNo.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        lblTrainName.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        lblTrainName.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel1.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel1.setText("Departure Time");

        jLabel12.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel12.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jDateChooser1.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel10))
                        .addGap(32, 32, 32)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jComboBoxSource, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBoxDestination, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel16)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(lblTrainNo, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel13)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jComboBoxPassenger, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel11)
                                .addGap(18, 18, 18)
                                .addComponent(jDateChooser1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))))
                .addGap(16, 16, 16))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(lblTrainName, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(91, 91, 91))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jComboBoxSource, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9))
                .addGap(28, 28, 28)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(jComboBoxDestination, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(36, 36, 36)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, 27, Short.MAX_VALUE)
                    .addComponent(jDateChooser1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(34, 34, 34)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jComboBoxPassenger, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel16)
                    .addComponent(lblTrainNo, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(53, 53, 53)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel17)
                    .addComponent(lblTrainName, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(42, 42, 42)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 3));

        jRadioButton1.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jRadioButton1.setText("First");
        jRadioButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton1ActionPerformed(evt);
            }
        });

        jRadioButtonSecond.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jRadioButtonSecond.setText("Second");
        jRadioButtonSecond.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButtonSecondActionPerformed(evt);
            }
        });

        lblFirst.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        lblFirst.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        lblSecond.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        lblSecond.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel6.setText("CLASS");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(51, 51, 51)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jRadioButtonSecond, javax.swing.GroupLayout.DEFAULT_SIZE, 89, Short.MAX_VALUE)
                    .addComponent(jRadioButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 53, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lblSecond, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblFirst, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 34, Short.MAX_VALUE))
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(152, 152, 152)
                .addComponent(jLabel6)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(52, 52, 52)
                        .addComponent(jRadioButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jRadioButtonSecond, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addContainerGap(12, Short.MAX_VALUE)
                        .addComponent(jLabel6)
                        .addGap(18, 18, 18)
                        .addComponent(lblFirst, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(40, 40, 40)
                        .addComponent(lblSecond, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(38, 38, 38))
        );

        jButton1.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jButton1.setText("BACK");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jButton2.setText("NEXT");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jButton3.setText("Receipt");
        jButton3.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jButton3.setPreferredSize(new java.awt.Dimension(81, 29));
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        txtbill.setEditable(false);
        txtbill.setColumns(20);
        txtbill.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        txtbill.setRows(5);
        txtbill.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        jScrollPane1.setViewportView(txtbill);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(18, 18, 18)
                                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGap(18, 18, 18))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(242, 242, 242)
                                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(97, 97, 97)
                                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 310, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(37, 37, 37)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 34, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton2))
                .addGap(19, 19, 19))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jComboBoxSourceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxSourceActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBoxSourceActionPerformed

    private void jComboBoxPassengerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxPassengerActionPerformed
        // TODO add your handling code here:
        if(jComboBoxDestination.getSelectedItem().equals("Pune") && jComboBoxSource.getSelectedItem().equals("Mumbai") && jComboBoxPassenger.getSelectedItem().equals("Two") && jRadioButton1.isSelected())
        {
           lblFirst.setText("Rs 480/-");
           lblTrainNo.setText("01071");
           lblTrainName.setText("Indrayani");
           jLabel12.setText("09:00 IST");
           txtbill.setText(null);
        }
         if(jComboBoxDestination.getSelectedItem().equals("Pune") && jComboBoxSource.getSelectedItem().equals("Mumbai") && jComboBoxPassenger.getSelectedItem().equals("Three") && jRadioButton1.isSelected())
        {
           lblFirst.setText("Rs 720/-");
           lblTrainNo.setText("01071");
           lblTrainName.setText("Indrayani");
           jLabel12.setText("09:00 IST");
           txtbill.setText(null);
        }
          if(jComboBoxDestination.getSelectedItem().equals("Pune") && jComboBoxSource.getSelectedItem().equals("Mumbai") && jComboBoxPassenger.getSelectedItem().equals("Four") && jRadioButton1.isSelected())
        {
           lblFirst.setText("Rs 960/-");
           lblTrainNo.setText("01071");
           lblTrainName.setText("Indrayani");
           jLabel12.setText("09:00 IST");
           txtbill.setText(null);
        }
        if(jComboBoxDestination.getSelectedItem().equals("Delhi") && jComboBoxSource.getSelectedItem().equals("Mumbai") && jComboBoxPassenger.getSelectedItem().equals("Two") && jRadioButton1.isSelected())
        {
           lblFirst.setText("Rs 4002/-");
              lblTrainNo.setText("01019");
              lblTrainName.setText("Rajdhani");
              jLabel12.setText("13:00 IST");
              txtbill.setText(null);
        }
        if(jComboBoxDestination.getSelectedItem().equals("Delhi") && jComboBoxSource.getSelectedItem().equals("Mumbai") && jComboBoxPassenger.getSelectedItem().equals("Three") && jRadioButton1.isSelected())
        {
           lblFirst.setText("Rs 8004/-");
              lblTrainNo.setText("01019");
              lblTrainName.setText("Rajdhani");
              jLabel12.setText("13:00 IST");
              txtbill.setText(null);
        }
        if(jComboBoxDestination.getSelectedItem().equals("Delhi") && jComboBoxSource.getSelectedItem().equals("Mumbai") && jComboBoxPassenger.getSelectedItem().equals("Four") && jRadioButton1.isSelected())
        {
           lblFirst.setText("Rs 12006/-");
              lblTrainNo.setText("01019");
              lblTrainName.setText("Rajdhani");
              jLabel12.setText("13:00 IST");
              txtbill.setText(null);
        }
                if(jComboBoxDestination.getSelectedItem().equals("Udaipur") && jComboBoxSource.getSelectedItem().equals("Mumbai") && jRadioButton1.isSelected() && jComboBoxPassenger.getSelectedItem().equals("Two"))
        {
           lblFirst.setText("Rs 2000/-");
           lblTrainNo.setText("01093");
           lblTrainName.setText("Udaipur Express");
           jLabel12.setText("16:00 IST");
           txtbill.setText(null);
        }
                        if(jComboBoxDestination.getSelectedItem().equals("Udaipur") && jComboBoxSource.getSelectedItem().equals("Mumbai") && jRadioButton1.isSelected() && jComboBoxPassenger.getSelectedItem().equals("Three"))
        {
           lblFirst.setText("Rs 3000/-");
           lblTrainNo.setText("01093");
           lblTrainName.setText("Udaipur Express");
           jLabel12.setText("16:00 IST");
           txtbill.setText(null);
        }
                                if(jComboBoxDestination.getSelectedItem().equals("Udaipur") && jComboBoxSource.getSelectedItem().equals("Mumbai") && jRadioButton1.isSelected() && jComboBoxPassenger.getSelectedItem().equals("Four"))
        {
           lblFirst.setText("Rs 4000/-");
           lblTrainNo.setText("01093");
           lblTrainName.setText("Udaipur Express");
           jLabel12.setText("16:00 IST");
           txtbill.setText(null);
        }
                 if(jComboBoxDestination.getSelectedItem().equals("Surat") && jComboBoxSource.getSelectedItem().equals("Mumbai") && jRadioButton1.isSelected() && jComboBoxPassenger.getSelectedItem().equals("Two"))
        {
           lblFirst.setText("Rs 1600/-");
           lblTrainNo.setText("01301");
           lblTrainName.setText("Karnavati Express");
           jLabel12.setText("20:00 IST");
           txtbill.setText(null);
        }
                 if(jComboBoxDestination.getSelectedItem().equals("Surat") && jComboBoxSource.getSelectedItem().equals("Mumbai") && jRadioButton1.isSelected() && jComboBoxPassenger.getSelectedItem().equals("Three"))
        {
           lblFirst.setText("Rs 2400/-");
           lblTrainNo.setText("01301");
           lblTrainName.setText("Karnavati Express");
           jLabel12.setText("20:00 IST");
           txtbill.setText(null);
        }
                 if(jComboBoxDestination.getSelectedItem().equals("Surat") && jComboBoxSource.getSelectedItem().equals("Mumbai") && jRadioButton1.isSelected() && jComboBoxPassenger.getSelectedItem().equals("Four"))
        {
           lblFirst.setText("Rs 3200/-");
           lblTrainNo.setText("01301");
           lblTrainName.setText("Karnavati Express");
           jLabel12.setText("20:00 IST");
           txtbill.setText(null);
        }                               
        if(jComboBoxDestination.getSelectedItem().equals("Pune") && jComboBoxSource.getSelectedItem().equals("Mumbai") && jRadioButtonSecond.isSelected() && jComboBoxPassenger.getSelectedItem().equals("Two"))
        {
           lblSecond.setText("Rs 240/-");
             lblTrainNo.setText("01071");
             lblTrainName.setText("Indrayani");
             jLabel12.setText("09:00 IST");
             txtbill.setText(null);
        }
        if(jComboBoxDestination.getSelectedItem().equals("Pune") && jComboBoxSource.getSelectedItem().equals("Mumbai") && jRadioButtonSecond.isSelected() && jComboBoxPassenger.getSelectedItem().equals("Three"))
        {
           lblSecond.setText("Rs 360/-");
             lblTrainNo.setText("01071");
             lblTrainName.setText("Indrayani");
             jLabel12.setText("09:00 IST");
             txtbill.setText(null);
        }
        if(jComboBoxDestination.getSelectedItem().equals("Pune") && jComboBoxSource.getSelectedItem().equals("Mumbai") && jRadioButtonSecond.isSelected() && jComboBoxPassenger.getSelectedItem().equals("Four"))
        {
           lblSecond.setText("Rs 480/-");
             lblTrainNo.setText("01071");
             lblTrainName.setText("Indrayani");
             jLabel12.setText("09:00 IST");
             txtbill.setText(null);
        }
        if(jComboBoxDestination.getSelectedItem().equals("Delhi") && jComboBoxSource.getSelectedItem().equals("Mumbai") && jRadioButtonSecond.isSelected() && jComboBoxPassenger.getSelectedItem().equals("Two"))
        {
           lblSecond.setText("Rs 2001/-");
             lblTrainNo.setText("01019");
             lblTrainName.setText("Rajdhani");
             jLabel12.setText("13:00 IST");
             txtbill.setText(null);
        }
        if(jComboBoxDestination.getSelectedItem().equals("Delhi") && jComboBoxSource.getSelectedItem().equals("Mumbai") && jRadioButtonSecond.isSelected() && jComboBoxPassenger.getSelectedItem().equals("Three"))
        {
           lblSecond.setText("Rs 3001/-");
             lblTrainNo.setText("01019");
             lblTrainName.setText("Rajdhani");
             jLabel12.setText("13:00 IST");
             txtbill.setText(null);
        }
        if(jComboBoxDestination.getSelectedItem().equals("Delhi") && jComboBoxSource.getSelectedItem().equals("Mumbai") && jRadioButtonSecond.isSelected() && jComboBoxPassenger.getSelectedItem().equals("Four"))
        {
           lblSecond.setText("Rs 4001/-");
             lblTrainNo.setText("01019");
             lblTrainName.setText("Rajdhani");
             jLabel12.setText("13:00 IST");
             txtbill.setText(null);
        }
        if(jComboBoxDestination.getSelectedItem().equals("Udaipur") && jComboBoxSource.getSelectedItem().equals("Mumbai") && jRadioButtonSecond.isSelected() && jComboBoxPassenger.getSelectedItem().equals("Two"))
        {
           lblSecond.setText("Rs 1000/-");
           lblTrainNo.setText("01093");
           lblTrainName.setText("Udaipur Express");
           jLabel12.setText("16:00 IST");
           txtbill.setText(null);
        }
        if(jComboBoxDestination.getSelectedItem().equals("Udaipur") && jComboBoxSource.getSelectedItem().equals("Mumbai") && jRadioButtonSecond.isSelected() && jComboBoxPassenger.getSelectedItem().equals("Three"))
        {
           lblSecond.setText("Rs 1500/-");
           lblTrainNo.setText("01093");
           lblTrainName.setText("Udaipur Express");
           jLabel12.setText("16:00 IST");
           txtbill.setText(null);
        }
        if(jComboBoxDestination.getSelectedItem().equals("Udaipur") && jComboBoxSource.getSelectedItem().equals("Mumbai") && jRadioButtonSecond.isSelected() && jComboBoxPassenger.getSelectedItem().equals("Four"))
        {
           lblSecond.setText("Rs 2000/-");
           lblTrainNo.setText("01093");
           lblTrainName.setText("Udaipur Express");
           jLabel12.setText("16:00 IST");
           txtbill.setText(null);
        }
             if(jComboBoxDestination.getSelectedItem().equals("Surat") && jComboBoxSource.getSelectedItem().equals("Mumbai") && jRadioButtonSecond.isSelected() && jComboBoxPassenger.getSelectedItem().equals("Two"))
        {
           lblSecond.setText("Rs 800/-");
           lblTrainNo.setText("01301");
           lblTrainName.setText("Karnavati Express");
           jLabel12.setText("20:00 IST");
           txtbill.setText(null);
        }     
            if(jComboBoxDestination.getSelectedItem().equals("Surat") && jComboBoxSource.getSelectedItem().equals("Mumbai") && jRadioButtonSecond.isSelected() && jComboBoxPassenger.getSelectedItem().equals("Three"))
        {
           lblSecond.setText("Rs 1200/-");
           lblTrainNo.setText("01301");
           lblTrainName.setText("Karnavati Express");
           jLabel12.setText("20:00 IST");
           txtbill.setText(null);
        }  
             if(jComboBoxDestination.getSelectedItem().equals("Surat") && jComboBoxSource.getSelectedItem().equals("Mumbai") && jRadioButtonSecond.isSelected() && jComboBoxPassenger.getSelectedItem().equals("Four"))
        {
           lblSecond.setText("Rs 1600/-");
           lblTrainNo.setText("01301");
           lblTrainName.setText("Karnavati Express");
           jLabel12.setText("20:00 IST");
           txtbill.setText(null);
        }  
    }//GEN-LAST:event_jComboBoxPassengerActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        if(Validation()==true){
            databaseConnection();
            TicketBooking tb = new TicketBooking();
            tb.show();
            dispose();
        }
        
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jComboBoxDestinationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxDestinationActionPerformed
        // TODO add your handling code here:
        if(jComboBoxDestination.getSelectedItem().equals("Pune") && jComboBoxSource.getSelectedItem().equals("Mumbai") && jRadioButton1.isSelected())
        {
           lblFirst.setText("Rs 240/-");
           lblTrainNo.setText("01071");
           lblTrainName.setText("Indrayani");
           jLabel12.setText("09:00 IST");
           txtbill.setText(null);
        }
        if(jComboBoxDestination.getSelectedItem().equals("Delhi") && jComboBoxSource.getSelectedItem().equals("Mumbai") && jRadioButton1.isSelected())
        {
           lblFirst.setText("Rs 2001/-");
              lblTrainNo.setText("01019");
              lblTrainName.setText("Rajdhani");
              jLabel12.setText("13:00 IST");
              txtbill.setText(null);
        }
                if(jComboBoxDestination.getSelectedItem().equals("Udaipur") && jComboBoxSource.getSelectedItem().equals("Mumbai") && jRadioButton1.isSelected())
        {
           lblFirst.setText("Rs 1000/-");
           lblTrainNo.setText("01093");
           lblTrainName.setText("Udaipur Express");
           jLabel12.setText("16:00 IST");
           txtbill.setText(null);
        }
                 if(jComboBoxDestination.getSelectedItem().equals("Surat") && jComboBoxSource.getSelectedItem().equals("Mumbai") && jRadioButton1.isSelected())
        {
           lblFirst.setText("Rs 800/-");
           lblTrainNo.setText("01301");
           lblTrainName.setText("Karnavati Express");
           jLabel12.setText("20:00 IST");
           txtbill.setText(null);
        }
                 
                 
        if(jComboBoxDestination.getSelectedItem().equals("Pune") && jComboBoxSource.getSelectedItem().equals("Mumbai") && jRadioButtonSecond.isSelected())
        {
           lblSecond.setText("Rs 120/-");
             lblTrainNo.setText("01071");
             lblTrainName.setText("Indrayani");
             jLabel12.setText("09:00 IST");
             txtbill.setText(null);
        }
        if(jComboBoxDestination.getSelectedItem().equals("Delhi") && jComboBoxSource.getSelectedItem().equals("Mumbai") && jRadioButtonSecond.isSelected())
        {
           lblSecond.setText("Rs 1001/-");
             lblTrainNo.setText("01019");
             lblTrainName.setText("Rajdhani");
             jLabel12.setText("13:00 IST");
             txtbill.setText(null);
        }
                if(jComboBoxDestination.getSelectedItem().equals("Udaipur") && jComboBoxSource.getSelectedItem().equals("Mumbai") && jRadioButtonSecond.isSelected())
        {
           lblSecond.setText("Rs 500/-");
           lblTrainNo.setText("01093");
           lblTrainName.setText("Udaipur Express");
           jLabel12.setText("16:00 IST");
           txtbill.setText(null);
        }
                 if(jComboBoxDestination.getSelectedItem().equals("Surat") && jComboBoxSource.getSelectedItem().equals("Mumbai") && jRadioButtonSecond.isSelected())
        {
           lblSecond.setText("Rs 400/-");
           lblTrainNo.setText("01301");
           lblTrainName.setText("Karnavati Express");
           jLabel12.setText("20:00 IST");
           txtbill.setText(null);
        }                 
    }//GEN-LAST:event_jComboBoxDestinationActionPerformed

    private void jRadioButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton1ActionPerformed
        // TODO add your handling code here:
        if(jRadioButton1.isSelected()==true)
        {
            jComboBoxDestination.setEnabled(true);
            lblFirst.setText(null);
            lblSecond.setText(null);
            lblTrainNo.setText(null);
            lblTrainName.setText(null);
            jRadioButtonSecond.setSelected(false);
            jComboBoxDestination.setSelectedItem("None");
            jComboBoxSource.setSelectedItem("None");
            jComboBoxPassenger.setSelectedItem("One");
            txtbill.setText(null);
        }
        if(jRadioButton1.isSelected()==false)
        {
            jComboBoxDestination.setEnabled(false);
            lblFirst.setText(null);
            lblSecond.setText(null);
            lblTrainNo.setText(null);
            lblTrainName.setText(null);
            jRadioButtonSecond.setSelected(false);
            jComboBoxDestination.setSelectedItem("None");
            jComboBoxSource.setSelectedItem("None");
            jComboBoxPassenger.setSelectedItem("One");
            txtbill.setText(null);
        }        
    }//GEN-LAST:event_jRadioButton1ActionPerformed

    private void txtPhoneNoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPhoneNoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPhoneNoActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
       NewTrain nt = new NewTrain();
       nt.show();
       dispose();
       
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jRadioButtonSecondActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButtonSecondActionPerformed
        // TODO add your handling code here:
                if(jRadioButtonSecond.isSelected()==true)
        {
            jComboBoxDestination.setEnabled(true);
            lblFirst.setText(null);
            lblSecond.setText(null);
            lblTrainNo.setText(null);
            lblTrainName.setText(null);
            jRadioButton1.setSelected(false);
            jComboBoxDestination.setSelectedItem("None");
            jComboBoxSource.setSelectedItem("None");
            jComboBoxPassenger.setSelectedItem("One");
            txtbill.setText(null);
        }
            if(jRadioButtonSecond.isSelected()==false)
        {
            jComboBoxDestination.setEnabled(false);
            lblFirst.setText(null);
            lblSecond.setText(null);
            lblTrainNo.setText(null);
            lblTrainName.setText(null);
            jRadioButton1.setSelected(false);
            jComboBoxDestination.setSelectedItem("None");
            jComboBoxSource.setSelectedItem("None");
            jComboBoxPassenger.setSelectedItem("One");
            txtbill.setText(null);
        }
    }//GEN-LAST:event_jRadioButtonSecondActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        Bill();
    }//GEN-LAST:event_jButton3ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TrainBooking.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TrainBooking.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TrainBooking.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TrainBooking.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TrainBooking().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JComboBox<String> jComboBoxDestination;
    private javax.swing.JComboBox<String> jComboBoxPassenger;
    private javax.swing.JComboBox<String> jComboBoxSource;
    private com.toedter.calendar.JDateChooser jDateChooser1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JRadioButton jRadioButtonSecond;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblFirst;
    private javax.swing.JLabel lblSecond;
    private javax.swing.JLabel lblTrainName;
    private javax.swing.JLabel lblTrainNo;
    private javax.swing.JTextField txtAge;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtName;
    private javax.swing.JTextField txtPhoneNo;
    private javax.swing.JTextArea txtbill;
    // End of variables declaration//GEN-END:variables
}


