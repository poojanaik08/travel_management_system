/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package car_booking;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;
import login_sys.home_page;

/**
 *
 * @author TANVI
 */
public class car extends javax.swing.JFrame {

    /**
     * Creates new form car
     */
    public car() {
        initComponents();
    }
    
    public void bill(){
        String Name=txtfullname.getText();
        
        String Age=txtage.getText();
        String Phone= txtphone.getText();
        String Email=txtemail.getText();
        String Time = txtTime.getText();
        String fiveseater = lblfiveseater.getText();
        String sevenseater = lblsevenseater.getText();
        String Destination = (String) jComboBox2.getSelectedItem();
        String Source = (String) jComboBoxCity.getSelectedItem();
        SimpleDateFormat dateFormt = new SimpleDateFormat("dd-MMM-y");
        String date = dateFormt.format(jDateChooser1.getDate());
        String Date = dateFormt.format(jDateChooser2.getDate());
        if(jDateChooser1.isShowing()==true){
            txtbill.setText(null);
        }
        if(jDateChooser2.isShowing()==true){
            txtbill.setText(null);
        }
        
        txtbill.setText(txtbill.getText()+"**************************************************\n");
        txtbill.setText(txtbill.getText()+"**********************RECEIPT********************\n");
        txtbill.setText(txtbill.getText()+"**************************************************\n\n");
        txtbill.setText(txtbill.getText()+"Passenger's Name:         " + Name +"\n");
        txtbill.setText(txtbill.getText()+"Passenger's Age:            " + Age +"\n");
        txtbill.setText(txtbill.getText()+"Passenger's Phone No.:  " + Phone +"\n");
        txtbill.setText(txtbill.getText()+"Passenger's Email:          "+ Email +"\n\n");
        
        txtbill.setText(txtbill.getText()+"Destination:                      "+ Destination+ "\n");
        txtbill.setText(txtbill.getText()+"Source:                            "+ Source+ "\n");
        txtbill.setText(txtbill.getText()+"Time:                              "+ Time+"\n");
        txtbill.setText(txtbill.getText()+"Date of Journey:              "+ date+"\n");
        txtbill.setText(txtbill.getText()+"End date of journey:        "+ Date+"\n\n");
        
        if(jRadioButton3.isSelected()&&jRadioButtonac.isSelected()){
            txtbill.setText(txtbill.getText() + "Seater Type:                    " + "Five Seater\n");
            txtbill.setText(txtbill.getText()+"AC/Non AC:                    AC\n");
            txtbill.setText(txtbill.getText() + "Total Amount:                  " + fiveseater + "\n");
        }
         if(jRadioButton3.isSelected()&&jRadioButtonnonac.isSelected()){
           txtbill.setText(txtbill.getText() + "Seater Type:                     " + "Five Seater\n");
           txtbill.setText(txtbill.getText()+"AC/Non AC:                     Non AC\n");
           txtbill.setText(txtbill.getText() + "Total Amount:                   " + fiveseater + "\n");
        }
        if(jRadioButton1.isSelected()&&jRadioButtonac.isSelected()){
            txtbill.setText(txtbill.getText() + "Seater Type:                    " + "Seven Seater\n");
            txtbill.setText(txtbill.getText()+"AC/Non AC:                    AC\n");
            txtbill.setText(txtbill.getText() + "Total Amount:                   " + sevenseater + "\n");
        }
        if(jRadioButton1.isSelected()&&jRadioButtonnonac.isSelected()){
            txtbill.setText(txtbill.getText() + "Seater Type:                    " + "Seven Seater\n");
            txtbill.setText(txtbill.getText()+"AC/Non AC:                    Non AC\n");
            txtbill.setText(txtbill.getText() + "Total Amount:                  " + sevenseater + "\n");
        }
        txtbill.setText(txtbill.getText()+"\n\n\n\n**************************************************\n");
        txtbill.setText(txtbill.getText()+"Note: Amount is inclusive of all taxes\n");
        txtbill.setText(txtbill.getText()+"Please take a screenshot for further reference");
    }
    
    public boolean validation()
    {
        String fullName, age, phoneNo, email, address, DateOfJourney, EndOfJourney, time ;
        Date doj,eoj;
        fullName=txtfullname.getText();
        age=txtage.getText();
        phoneNo=txtphone.getText();
        email= txtemail.getText();
        address=txtaddress.getText();
        time=txtTime.getText();
        doj=jDateChooser1.getDate();
        eoj=jDateChooser2.getDate();
        
        
        if(fullName.equals("")) {
            JOptionPane.showMessageDialog(this, "Please enter name");
            return false;
        }
        if(age.equals("")) {
            JOptionPane.showMessageDialog(this, "Please enter age");
            return false;
        }
        if(email.equals("")) {
            JOptionPane.showMessageDialog(this, "Please enter email");
            return false;
        }
        if(address.equals("")) {
            JOptionPane.showMessageDialog(this, "Please enter address");
            return false;
        }
        if(time.equals("")) {
            JOptionPane.showMessageDialog(this, "Please enter time of journey");
            return false;
        }
        if(doj==null) {
            JOptionPane.showMessageDialog(this, "Please enter date of journey");
            return false;
        }
        if(eoj==null) {
            JOptionPane.showMessageDialog(this, "Please enter end date of journey");
            return false;
        }
        if(jRadioButton3.isSelected()==false && jRadioButton1.isSelected()==false )
        {
            JOptionPane.showMessageDialog(this, "Please select type of car");
            return false;
        }
        if(jRadioButtonac.isSelected()==false && jRadioButtonnonac.isSelected()==false )
        {
            JOptionPane.showMessageDialog(this, "Please select AC or Non AC");
            return false;
        }
        if(jComboBox2.getSelectedItem().equals("None"))
        {
            JOptionPane.showMessageDialog(this, "Please select a destination");
            return false;
        }
        
        return true;

    }
    
    public void dataBaseConnection(){
        String name,  phoneno, email,time ;
        
        name=txtfullname.getText();
        phoneno=txtphone.getText();
       
        email= txtemail.getText();
        
        time=txtTime.getText();
        String destination = (String) jComboBox2.getSelectedItem();
        String source = (String) jComboBoxCity.getSelectedItem();
        SimpleDateFormat dateFormt = new SimpleDateFormat("dd-MMM-y");
        String doj = dateFormt.format(jDateChooser1.getDate());
        String eoj = dateFormt.format(jDateChooser2.getDate());
        try{
        Class.forName("org.postgresql.Driver");
        Connection con= DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres","postgres","pluto21");
        Statement st= con.createStatement();
        String sql="insert into information_schema.car_booking values('"+name+"','"+phoneno+"','"+email+"','"+source+"','"+destination+"','"+doj+"','"+eoj+"','"+time+"')";
        st.execute(sql);
        
       
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txtfullname = new javax.swing.JTextField();
        txtage = new javax.swing.JTextField();
        txtphone = new javax.swing.JTextField();
        txtemail = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jRadioButton3 = new javax.swing.JRadioButton();
        jRadioButton1 = new javax.swing.JRadioButton();
        lblfiveseater = new javax.swing.JLabel();
        lblsevenseater = new javax.swing.JLabel();
        lblac = new javax.swing.JLabel();
        lblnonac = new javax.swing.JLabel();
        jRadioButtonac = new javax.swing.JRadioButton();
        jRadioButtonnonac = new javax.swing.JRadioButton();
        jPanel4 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jComboBox2 = new javax.swing.JComboBox<>();
        jDateChooser1 = new com.toedter.calendar.JDateChooser();
        jDateChooser2 = new com.toedter.calendar.JDateChooser();
        txttime = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtaddress = new javax.swing.JTextPane();
        txtTime = new javax.swing.JTextField();
        lblcity = new javax.swing.JLabel();
        jComboBoxCity = new javax.swing.JComboBox<>();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtbill = new javax.swing.JTextArea();
        jButton3 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1222, 643));
        setPreferredSize(new java.awt.Dimension(1350, 675));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 4));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        jLabel1.setText("CAR BOOKING");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 20, -1, 40));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 12, 1300, 70));

        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 4));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel2.setText("Full Name:");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(25, 53, -1, 24));

        jLabel3.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel3.setText("Age:");
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(25, 107, 31, -1));

        jLabel4.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel4.setText("Phone No:");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(25, 156, -1, -1));

        jLabel5.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel5.setText("email id:");
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(25, 203, 62, -1));

        txtfullname.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jPanel2.add(txtfullname, new org.netbeans.lib.awtextra.AbsoluteConstraints(142, 54, 228, -1));

        txtage.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jPanel2.add(txtage, new org.netbeans.lib.awtextra.AbsoluteConstraints(142, 104, 228, -1));

        txtphone.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jPanel2.add(txtphone, new org.netbeans.lib.awtextra.AbsoluteConstraints(142, 153, 228, -1));

        txtemail.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        txtemail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtemailActionPerformed(evt);
            }
        });
        jPanel2.add(txtemail, new org.netbeans.lib.awtextra.AbsoluteConstraints(142, 203, 228, -1));

        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel6.setText("PERSONAL DETAILS");
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(174, 14, -1, -1));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 100, 445, 260));

        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 4));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel7.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel7.setText("CAR TYPE");
        jPanel3.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(196, 24, 109, -1));

        jRadioButton3.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jRadioButton3.setText("Five Seater");
        jRadioButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton3ActionPerformed(evt);
            }
        });
        jPanel3.add(jRadioButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 110, -1));

        jRadioButton1.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jRadioButton1.setText("Seven Seater");
        jRadioButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton1ActionPerformed(evt);
            }
        });
        jPanel3.add(jRadioButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, -1, -1));

        lblfiveseater.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        lblfiveseater.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel3.add(lblfiveseater, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 60, 100, 29));

        lblsevenseater.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        lblsevenseater.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel3.add(lblsevenseater, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 120, 100, 29));

        lblac.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        lblac.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel3.add(lblac, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 60, 100, 29));

        lblnonac.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        lblnonac.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel3.add(lblnonac, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 120, 100, 29));

        jRadioButtonac.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jRadioButtonac.setText("AC");
        jRadioButtonac.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButtonacActionPerformed(evt);
            }
        });
        jPanel3.add(jRadioButtonac, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 60, -1, -1));

        jRadioButtonnonac.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jRadioButtonnonac.setText("Non AC");
        jRadioButtonnonac.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButtonnonacActionPerformed(evt);
            }
        });
        jPanel3.add(jRadioButtonnonac, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 120, -1, -1));

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 380, 445, 194));

        jPanel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 4));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel8.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel8.setText("BOOKING DETAILS");
        jPanel4.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 10, -1, 29));

        jLabel9.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel9.setText("Address");
        jPanel4.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 53, 74, 34));

        jLabel10.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel10.setText("Destination");
        jPanel4.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 200, 89, -1));

        jLabel12.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel12.setText("Date of Journey");
        jPanel4.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 260, -1, -1));

        jLabel14.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel14.setText("End of Journey");
        jPanel4.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 330, 118, -1));

        jComboBox2.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "None", "Ratnagiri", "Pune", "Amravati", "Kolhapur", " " }));
        jComboBox2.setEnabled(false);
        jComboBox2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox2ActionPerformed(evt);
            }
        });
        jPanel4.add(jComboBox2, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 200, 240, 30));
        jPanel4.add(jDateChooser1, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 260, 240, 30));
        jPanel4.add(jDateChooser2, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 330, 240, 30));

        txttime.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        txttime.setText("Time (24 Hour)");
        jPanel4.add(txttime, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 400, -1, -1));

        jScrollPane2.setViewportView(txtaddress);

        jPanel4.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(175, 53, 250, 63));

        txtTime.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        txtTime.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTimeActionPerformed(evt);
            }
        });
        jPanel4.add(txtTime, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 400, 240, -1));

        lblcity.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        lblcity.setText("City");
        jPanel4.add(lblcity, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 140, 36, -1));

        jComboBoxCity.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jComboBoxCity.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "None", "Mumbai", " ", " " }));
        jPanel4.add(jComboBoxCity, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 140, 240, 30));

        getContentPane().add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 100, 440, 474));

        jButton1.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jButton1.setText("Back");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 597, 99, 36));

        jButton2.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jButton2.setText("Payment");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(1230, 590, 95, 36));

        txtbill.setEditable(false);
        txtbill.setColumns(20);
        txtbill.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        txtbill.setRows(5);
        txtbill.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 3));
        jScrollPane1.setViewportView(txtbill);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(940, 100, 380, 474));

        jButton3.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jButton3.setText("Receipt");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(940, 590, 88, 36));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void txtemailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtemailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtemailActionPerformed

    private void jRadioButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton3ActionPerformed
        if(jRadioButton3.isSelected()==true)
        {
            jComboBox2.setEnabled(true);
            jRadioButton1.setSelected(false);
            lblsevenseater.setText(null);
            lblac.setText(null);
            lblnonac.setText(null);
            jComboBoxCity.setSelectedItem("None");
            txtbill.setText(null);
            jComboBox2.setSelectedItem("None");
        }
        if(jRadioButton3.isSelected()==false)
        {
            jComboBox2.setSelectedItem("None");
            jComboBox2.setEnabled(false);
            lblfiveseater.setText(null);
            lblac.setText(null);
            lblnonac.setText(null);
            jComboBoxCity.setSelectedItem("None");
            txtbill.setText(null);
        }
    }//GEN-LAST:event_jRadioButton3ActionPerformed

    private void jRadioButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton1ActionPerformed
        // TODO add your handling code here:
        if(jRadioButton1.isSelected()==true)
        {
            jComboBox2.setEnabled(true);
            jComboBox2.setSelectedItem("None");
            jRadioButton3.setSelected(false);
            lblfiveseater.setText(null);
            lblac.setText(null);
            lblnonac.setText(null);
            jComboBoxCity.setSelectedItem("None");
            txtbill.setText(null);
        }
        if(jRadioButton1.isSelected()==false)
        {
            jComboBox2.setSelectedItem("None");
            jComboBox2.setEnabled(false);
            lblsevenseater.setText(null);
            lblac.setText(null);
            lblnonac.setText(null);
            jComboBoxCity.setSelectedItem("None");
            txtbill.setText(null);
        }
    }//GEN-LAST:event_jRadioButton1ActionPerformed

    private void jComboBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox2ActionPerformed
      if((jComboBox2.getSelectedItem().equals("Ratnagiri"))&& jRadioButton3.isSelected()&& jComboBoxCity.getSelectedItem().equals("Mumbai"))
      {
          lblfiveseater.setText(" Rs 12000/-");
          lblac.setText("Rs 12000/-");
          jRadioButtonac.setSelected(true);
          txtbill.setText(null);
      }
      else if((jComboBox2.getSelectedItem().equals("Pune"))&& jRadioButton3.isSelected()&&jComboBoxCity.getSelectedItem().equals("Mumbai"))
      {
          lblfiveseater.setText("Rs 7200/-");
          lblac.setText("Rs 7200/-");
          jRadioButtonac.setSelected(true);
          txtbill.setText(null);
      }
      if((jComboBox2.getSelectedItem().equals("Amravati"))&&jRadioButton3.isSelected()&& jComboBoxCity.getSelectedItem().equals("Mumbai"))
      {
          lblfiveseater.setText("Rs 20400/-");
           lblac.setText("Rs 20400/-");
           jRadioButtonac.setSelected(true);
           txtbill.setText(null);
      }
      if((jComboBox2.getSelectedItem().equals("Kolhapur"))&& jRadioButton3.isSelected()&& jComboBoxCity.getSelectedItem().equals("Mumbai"))
      {  
          lblfiveseater.setText("Rs 13200/-");
           lblac.setText("Rs 13200/-");
           jRadioButtonac.setSelected(true);
           txtbill.setText(null);
      }
      
      if((jComboBox2.getSelectedItem().equals("Ratnagiri"))&& jRadioButton1.isSelected()&& jComboBoxCity.getSelectedItem().equals("Mumbai"))
      {
          lblsevenseater.setText("Rs 13200/-");
          lblac.setText("Rs 13200/-");
          jRadioButtonac.setSelected(true);
          txtbill.setText(null);
      }
      else if((jComboBox2.getSelectedItem().equals("Pune"))&& jRadioButton1.isSelected()&& jComboBoxCity.getSelectedItem().equals("Mumbai"))
      {
          lblsevenseater.setText("Rs 8400/-");
          lblac.setText("Rs 8400/-");
          jRadioButtonac.setSelected(true);
          txtbill.setText(null);
      }
      if((jComboBox2.getSelectedItem().equals("Amravati"))&&jRadioButton1.isSelected()&& jComboBoxCity.getSelectedItem().equals("Mumbai"))
      {
          lblsevenseater.setText("Rs 21600/-");
           lblac.setText("Rs 21600/-");
           jRadioButtonac.setSelected(true);
           txtbill.setText(null);
      }
      if((jComboBox2.getSelectedItem().equals("Kolhapur"))&& jRadioButton1.isSelected()&& jComboBoxCity.getSelectedItem().equals("Mumbai"))
      {  
          lblsevenseater.setText("Rs 14400/-");
           lblac.setText("Rs 14400/-");
           jRadioButtonac.setSelected(true);
           txtbill.setText(null);
      }
      
      if((jComboBox2.getSelectedItem().equals("Kolhapur"))&& jRadioButton1.isSelected()&&jRadioButtonnonac.isSelected()&& jComboBoxCity.getSelectedItem().equals("Mumbai"))
      {  
          lblsevenseater.setText("Rs 12000/-");
           lblnonac.setText("Rs 12000/-");
           jRadioButtonnonac.setSelected(true);
           lblac.setText(null);
           jRadioButtonac.setSelected(false);
           txtbill.setText(null);
      }
      if((jComboBox2.getSelectedItem().equals("Ratnagiri"))&& jRadioButton1.isSelected()&&jRadioButtonnonac.isSelected()&& jComboBoxCity.getSelectedItem().equals("Mumbai"))
      {  
          lblsevenseater.setText("Rs 10800/-");
           lblnonac.setText("Rs 10800/-");
           jRadioButtonnonac.setSelected(true);
           lblac.setText(null);
           jRadioButtonac.setSelected(false);
           txtbill.setText(null);
      }
     if((jComboBox2.getSelectedItem().equals("Pune"))&& jRadioButton1.isSelected()&&jRadioButtonnonac.isSelected()&& jComboBoxCity.getSelectedItem().equals("Mumbai"))
      {  
          lblsevenseater.setText("Rs 6000/-");
           lblnonac.setText("Rs 6000/-");
           jRadioButtonnonac.setSelected(true);
           lblac.setText(null);
           jRadioButtonac.setSelected(false);
           txtbill.setText(null);
      }
     if((jComboBox2.getSelectedItem().equals("Amravati"))&& jRadioButton1.isSelected()&&jRadioButtonnonac.isSelected()&& jComboBoxCity.getSelectedItem().equals("Mumbai"))
      {  
          lblsevenseater.setText("Rs 19200/-");
           lblnonac.setText("Rs 19200/-");
           jRadioButtonnonac.setSelected(true);
           lblac.setText(null);
           jRadioButtonac.setSelected(false);
           txtbill.setText(null);
      }
     
     
     
     //==========================================================================================================================
     
     if((jComboBox2.getSelectedItem().equals("Kolhapur"))&& jRadioButton3.isSelected()&&jRadioButtonnonac.isSelected()&& jComboBoxCity.getSelectedItem().equals("Mumbai"))
      {  
          lblfiveseater.setText("Rs 10800/-");
           lblnonac.setText("Rs 10800/-");
           jRadioButtonnonac.setSelected(true);
           lblac.setText(null);
           jRadioButtonac.setSelected(false);
           txtbill.setText(null);
      }
      if((jComboBox2.getSelectedItem().equals("Ratnagiri"))&& jRadioButton3.isSelected()&&jRadioButtonnonac.isSelected()&& jComboBoxCity.getSelectedItem().equals("Mumbai"))
      {  
          lblfiveseater.setText("Rs 9600/-");
           lblnonac.setText("Rs 9600/-");
           jRadioButtonnonac.setSelected(true);
           lblac.setText(null);
           jRadioButtonac.setSelected(false);
           txtbill.setText(null);
      }
     if((jComboBox2.getSelectedItem().equals("Pune"))&& jRadioButton3.isSelected()&&jRadioButtonnonac.isSelected()&& jComboBoxCity.getSelectedItem().equals("Mumbai"))
      {  
          lblfiveseater.setText("Rs 4800/-");
           lblnonac.setText("Rs 4800/-");
           jRadioButtonnonac.setSelected(true);
           lblac.setText(null);
           jRadioButtonac.setSelected(false);
           txtbill.setText(null);
      }
     if((jComboBox2.getSelectedItem().equals("Amravati"))&& jRadioButton3.isSelected()&&jRadioButtonnonac.isSelected()&& jComboBoxCity.getSelectedItem().equals("Mumbai"))
      {  
          lblfiveseater.setText("Rs 18000/-");
           lblnonac.setText("Rs 18000-");
           jRadioButtonnonac.setSelected(true);
           lblac.setText(null);
           jRadioButtonac.setSelected(false);
           txtbill.setText(null);
      }
     
      
      
    }//GEN-LAST:event_jComboBox2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
         NewCancel nc = new NewCancel();
         nc.show();
         dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jRadioButtonacActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButtonacActionPerformed
        // TODO add your handling code here:
        if(jRadioButtonac.isSelected()==true)
        {
            jRadioButtonnonac.setSelected(false);
            lblnonac.setText(null);
            lblac.setText(null);
            lblsevenseater.setText(null);
            lblfiveseater.setText(null);
            jComboBox2.setSelectedItem("None");
            jComboBoxCity.setSelectedItem("None");
            txtbill.setText(null);
        }
        if(jRadioButtonac.isSelected()==false)
        {
            jRadioButtonnonac.setSelected(false);
            lblac.setText(null);
            lblnonac.setText(null);
            lblsevenseater.setText(null);
            lblfiveseater.setText(null);
            jComboBox2.setSelectedItem("None");
            jComboBoxCity.setSelectedItem("None");
            txtbill.setText(null);
        }
    }//GEN-LAST:event_jRadioButtonacActionPerformed

    private void jRadioButtonnonacActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButtonnonacActionPerformed
        // TODO add your handling code here:
        if(jRadioButtonnonac.isSelected()==true)
        {
            jRadioButtonac.setSelected(false);
            lblnonac.setText(null);
            lblac.setText(null);
            lblsevenseater.setText(null);
            lblfiveseater.setText(null);
            jComboBox2.setSelectedItem("None");
            txtbill.setText(null);
        }
        if(jRadioButtonnonac.isSelected()==false)
        {
            jRadioButtonac.setSelected(false);
            lblnonac.setText(null);
            lblac.setText(null);
            lblsevenseater.setText(null);
            lblfiveseater.setText(null);
            jComboBox2.setSelectedItem("None");    
            txtbill.setText(null);
        }
    }//GEN-LAST:event_jRadioButtonnonacActionPerformed

    private void txtTimeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTimeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTimeActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        if(validation()==true){
           dataBaseConnection();
           CarPayment cp = new CarPayment();
           cp.show();
           dispose();
            
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        bill();
    }//GEN-LAST:event_jButton3ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(car.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(car.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(car.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(car.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new car().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JComboBox<String> jComboBoxCity;
    private com.toedter.calendar.JDateChooser jDateChooser1;
    private com.toedter.calendar.JDateChooser jDateChooser2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JRadioButton jRadioButton3;
    private javax.swing.JRadioButton jRadioButtonac;
    private javax.swing.JRadioButton jRadioButtonnonac;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lblac;
    private javax.swing.JLabel lblcity;
    private javax.swing.JLabel lblfiveseater;
    private javax.swing.JLabel lblnonac;
    private javax.swing.JLabel lblsevenseater;
    private javax.swing.JTextField txtTime;
    private javax.swing.JTextPane txtaddress;
    private javax.swing.JTextField txtage;
    private javax.swing.JTextArea txtbill;
    private javax.swing.JTextField txtemail;
    private javax.swing.JTextField txtfullname;
    private javax.swing.JTextField txtphone;
    private javax.swing.JLabel txttime;
    // End of variables declaration//GEN-END:variables

    
    
}
